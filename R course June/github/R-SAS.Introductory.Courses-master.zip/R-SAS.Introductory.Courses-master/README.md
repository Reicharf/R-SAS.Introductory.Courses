## Welcome to the "Statistical Analyses with R/SAS" introductory course GitHub page

Here you can find the example datasets as well as the latest codes applied in the courses. Please go to the respective folder above.
Don't hesitate to contact me about any of this.

Paul Schmidt
paul.schmidt@uni-hohenheim.de, 
[LinkedIn](https://www.linkedin.com/in/schmidtpaul1989/), 
[ResearchGate](https://www.researchgate.net/profile/Paul_Schmidt17)

![alt text](https://www.uni-hohenheim.de/fileadmin/uni_hohenheim/Intranet_MA/Hochschulkommunikation/Corporate-Design/Logo/Uni-Hohenheim-Logo-Blau-EN.jpg)
