rm(list=ls())
setwd("C:/Users/Paul/Desktop/R course")
dat <- read.delim("06 data Quantity.txt")